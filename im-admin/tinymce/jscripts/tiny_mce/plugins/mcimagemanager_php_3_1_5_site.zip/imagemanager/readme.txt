You can find the documentation with installation instuctions here:

ImageManager documentation:
http://wiki.moxiecode.com/index.php/MCImageManager:Index

FileManager documentation:
http://wiki.moxiecode.com/index.php/MCFileManager:Index

If you still have problems installing it use the forums at http://tinymce.moxiecode.com/punbb/index.php for support.
