<?php
	require_once("rpc.php");
?>